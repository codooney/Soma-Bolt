import React, { useState } from 'react';
import Layout from './components/Layout';
import UploadScreen from './components/UploadScreen';
import LoadingScreen from './components/LoadingScreen';
import ResultsDashboard from './components/ResultsDashboard';
import DetailedInsights from './components/DetailedInsights';

function App() {
  const [currentScreen, setCurrentScreen] = useState<'upload' | 'loading' | 'results' | 'details'>('upload');
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  const handleAnalyze = () => {
    setCurrentScreen('loading');
    // Simulate loading time
    setTimeout(() => {
      setCurrentScreen('results');
    }, 3000);
  };

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentScreen('details');
  };

  const handleBackToDashboard = () => {
    setCurrentScreen('results');
  };

  return (
    <Layout>
      {currentScreen === 'upload' && <UploadScreen onAnalyze={handleAnalyze} />}
      {currentScreen === 'loading' && <LoadingScreen />}
      {currentScreen === 'results' && (
        <ResultsDashboard onCategoryClick={handleCategoryClick} />
      )}
      {currentScreen === 'details' && (
        <DetailedInsights 
          categoryId={selectedCategory} 
          onBack={handleBackToDashboard}
        />
      )}
    </Layout>
  );
}

export default App;
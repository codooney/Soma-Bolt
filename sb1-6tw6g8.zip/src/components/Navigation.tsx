import React from 'react';
import { Home, Activity, ListTodo } from 'lucide-react';

export default function Navigation() {
  const [active, setActive] = React.useState('home');

  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'insights', icon: Activity, label: 'Insights' },
    { id: 'plan', icon: ListTodo, label: 'My Plan' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg shadow-lg border-t border-gray-100 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-around">
          {navItems.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => setActive(id)}
              className={`flex flex-col items-center py-3 px-5 transition-colors ${
                active === id
                  ? 'text-blue-600'
                  : 'text-gray-500 hover:text-blue-600'
              }`}
            >
              <Icon className="w-6 h-6 mb-1" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
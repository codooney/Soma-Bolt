import React from 'react';
import { Activity } from 'lucide-react';

interface UploadScreenProps {
  onAnalyze: () => void;
}

export default function UploadScreen({ onAnalyze }: UploadScreenProps) {
  const [file, setFile] = React.useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="min-h-[calc(100vh-9rem)] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="relative">
              <div className="absolute inset-0 animate-pulse bg-blue-200 rounded-full blur-xl opacity-50"></div>
              <Activity className="w-12 h-12 text-blue-600 relative z-10" />
            </div>
          </div>
          <h1 className="text-5xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Soma AI
          </h1>
          <p className="text-gray-600 text-lg">
            Upload your blood test results and get instant AI-powered health insights
          </p>
        </div>

        {/* Upload Section */}
        <div className="flex flex-col items-center justify-center gap-6">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept=".pdf,image/*"
            onChange={handleFileChange}
          />
          
          {!file ? (
            <button
              onClick={handleUploadClick}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5"
            >
              Upload Here
            </button>
          ) : (
            <div className="text-center">
              <div className="mb-4 text-gray-700">
                <span className="font-medium">{file.name}</span>
              </div>
              <button
                onClick={onAnalyze}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold px-8 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5"
              >
                Analyze Results
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}